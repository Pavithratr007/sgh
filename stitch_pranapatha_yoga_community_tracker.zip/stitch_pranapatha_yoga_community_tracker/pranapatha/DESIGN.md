---
name: PranaPatha
colors:
  surface: '#f9f9ff'
  surface-dim: '#d0daf0'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3ff'
  surface-container: '#e7eeff'
  surface-container-high: '#dee8ff'
  surface-container-highest: '#d9e3f9'
  on-surface: '#121c2c'
  on-surface-variant: '#414844'
  inverse-surface: '#273141'
  inverse-on-surface: '#ebf1ff'
  outline: '#717974'
  outline-variant: '#c1c8c3'
  surface-tint: '#426657'
  primary: '#3f6355'
  on-primary: '#ffffff'
  primary-container: '#587c6d'
  on-primary-container: '#f5fff8'
  inverse-primary: '#a8cfbd'
  secondary: '#486456'
  on-secondary: '#ffffff'
  secondary-container: '#caead8'
  on-secondary-container: '#4e6b5c'
  tertiary: '#8b4c11'
  on-tertiary: '#ffffff'
  tertiary-container: '#a96428'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#c4ebd9'
  primary-fixed-dim: '#a8cfbd'
  on-primary-fixed: '#002116'
  on-primary-fixed-variant: '#2a4d40'
  secondary-fixed: '#caead8'
  secondary-fixed-dim: '#aecebc'
  on-secondary-fixed: '#042015'
  on-secondary-fixed-variant: '#314c3f'
  tertiary-fixed: '#ffdcc4'
  tertiary-fixed-dim: '#ffb780'
  on-tertiary-fixed: '#2f1400'
  on-tertiary-fixed-variant: '#6f3800'
  background: '#f9f9ff'
  on-background: '#121c2c'
  surface-variant: '#d9e3f9'
typography:
  display:
    fontFamily: Nunito Sans
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
  display-mobile:
    fontFamily: Nunito Sans
    fontSize: 30px
    fontWeight: '800'
    lineHeight: 38px
  headline-lg:
    fontFamily: Nunito Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Nunito Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
  headline-md:
    fontFamily: Nunito Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-sm:
    fontFamily: Nunito Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Nunito Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Nunito Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Nunito Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Nunito Sans
    fontSize: 16px
    fontWeight: '700'
    lineHeight: 22px
  label-md:
    fontFamily: Nunito Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-sm:
    fontFamily: Nunito Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1.25rem
  space-xs: 0.375rem
  space-sm: 0.75rem
  space-md: 1.25rem
  space-lg: 2rem
  space-xl: 3rem
---

## Brand & Style

This design system embodies mindful tranquility, communal warmth, and radical accessibility. Designed for a volunteer-run yoga self-help collective, the interface must reassure, demystify record-keeping, and cultivate a sense of grounded sanctuary. Every interaction feels patient, breath-aligned, and hospitable.

The visual direction harmonizes **Calm Wellness** with **Humanist Minimalism**:
- **Generous Breathability**: Unhurried whitespace, soothing proportion ratios, and spacious tap targets eliminate administrative cognitive load.
- **Gentle Earth Tactility**: Warm creamy canvases replace harsh artificial whites, paired with botanical sage tones and restorative terra-cotta highlights.
- **Supportive Clarity**: Unambiguous affordances, large approachable typography, and friendly structural rounding welcome elder practitioners and first-time smartphone users alike.
- **Reassuring Presence**: Visual elements evoke natural light, woven textures, and botanical grace without superfluous clutter.

## Colors

The palette draws directly from natural ashram grounds, sunlit meditation halls, and herbal apothecary notes. It avoids clinical software blues and sterile grays in favor of restorative, organic pigments.

### Functional Palette Mapping
- **Canvas & Backgrounds**: Base backdrop uses Warm Cream (`#FAF6F0`). Raised surface cards utilize Pure Warm White (`#FFFFFF`) or Delicate Linen (`#FDFBF7`) to create soft, legible layering.
- **Primary (Sage Hearth)**: `#6B9080` serves as the primary anchor for core actions, navigational highlights, and vital state indicators.
- **Secondary (Botanical Mist)**: Supported by soft mist gradients and soothing accents—`#A4C3B2` (muted sage), `#CCE3DE` (dew tint), and `#EAF4F4` (airy wash) for badges, subtle table rows, and soft tag fills.
- **Tertiary & Accents (Dawn Glow & Terracotta)**: `#F4A261` provides a gentle sunlit highlight for active progress badges, attention markers, and celebratory milestones. `#E76F51` acts as a warm earthy accent for urgent reminders or subtle warnings without inducing alarm.
- **Text & Contrast (Deep Slate Charcoal)**: High-contrast legibility is maintained with `#2D3748` for primary body copy and `#1A202C` for headlines. Secondary guidance text rests comfortably at `#5A6578`.
- **Dividers & Borders**: Organic linen tone `#E9E4DC` ensures soft separation without rigid visual cages.

## Typography

Nunito Sans provides rounded, open geometry that balances humanist warmth with uncompromising legibility. Its balanced x-height and gentle terminals feel inherently friendly to users intimidated by complex digital forms.

- **Scale Rationale**: Base reading sizes are intentionally bumped to 18px and 16px to protect readability for aging eyes and mobile use in sunlit open-air yoga halls.
- **Hierarchy Structure**: Headlines use generous weights (700 and 800) to create comforting, distinct navigation landmarks across volunteer attendance registers, member logs, and session notes.
- **Letter Spacing & Line Height**: Slightly relaxed line spacing (1.45–1.55) gives content space to settle and prevents dense block fatigue.

## Layout & Spacing

The layout follows a responsive, fluid grid designed around effortless scanning and relaxed posture.

- **Breakpoints & Grids**:
  - **Mobile (<768px)**: 4-column layout, `gutter-mobile` (16px), `margin-mobile` (20px). Full-width touch cards, fixed bottom quick-action bars.
  - **Tablet (768px–1024px)**: 8-column layout, 24px gutters, 32px canvas margins. Two-column dashboard widgets.
  - **Desktop (>1024px)**: 12-column layout maxing out at a comfortable 1280px containment container to prevent wide, alienated layouts.
- **Spacing Rhythm**: Governed by multiples of 6px and 12px for an organic, slightly softer cadence than rigid 8px systems.
- **Touch Areas**: Interactive elements maintain an absolute minimum touch zone of 48px by 48px, with typical primary buttons standing tall at 54px to accommodate unsteady taps.

## Elevation & Depth

This design system avoids harsh artificial dropshadows, synthetic 3D bevels, or heavy borders. Spatial depth relies on **warm ambient light** and **tonal layering**:

1. **Ambient Sunlight (Cards & Modals)**:
   - Shadows are wide-diffused, tinted with warm umber and sage instead of neutral black: `0 8px 24px -4px rgba(107, 144, 128, 0.08), 0 4px 12px -2px rgba(45, 55, 72, 0.04)`.
   - Modals and persistent popovers use an elevated float: `0 20px 36px -8px rgba(45, 55, 72, 0.12)`.
2. **Subtle Tactility**:
   - Elevated cards pair ambient light with an organic, whisper-thin outline: `1px solid #E9E4DC`.
3. **Backdrop Veil**:
   - Overlays use a warm frosted glaze: `rgba(250, 246, 240, 0.82)` with a delicate `8px` backdrop blur, letting yoga room textures subtly breathe underneath without disorienting the practitioner.

## Shapes

The shape system embraces continuous curves inspired by river stones, lotus petals, and yoga mats.

- **Standard Containers & Cards**: Employ a gentle 16px radius (`rounded-lg`), softening sharp technical edges and framing volunteer logs with hospitality.
- **Buttons, Badges, & Chips**: Use full pill radii (`rounded-full` / `9999px`) to emphasize touch-friendliness, physical safety, and organic approachability.
- **Modals & Bottom Drawers**: Feature generous 24px top radii (`rounded-xl`), creating an inviting, blanket-like embrace on mobile viewports.
- **Iconography & Accents**: Utilize rounded stroke caps and organic circular badge backdrops.

## Components

### Buttons
- **Primary Button**: High-comfort pill shape (`rounded-full`), min-height 52px, filled with Sage Green (`#6B9080`), text in Pure White (`#FFFFFF`) at `label-lg`. Pressed state deepens to `#557366`. Warm hover lift of -1px.
- **Secondary Button**: Outlined in Warm Cream Border (`#E9E4DC`) or Sage Green (`#6B9080`) over Warm Cream Card (`#FDFBF7`), text in Deep Charcoal (`#2D3748`).
- **Accent Button (Donate / Milestone / Urgency)**: Filled with Soft Warm Orange (`#F4A261`), dark text (`#1A202C`).

### Cards & Surface Tiles
- **Member / Class Record Card**: Crisp Linen surface (`#FFFFFF` or `#FDFBF7`), 16px rounded corners, border `1px solid #E9E4DC`, padding `space-md` to `space-lg`. Contains member yoga tier, attendance tally, and gentle wellness check tags.
- **Interactive State**: Border transitions to `#6B9080` on focus or selection.

### Chips & Filter Tags
- **Filter Chips**: Height 36px, full pill curve. Inactive: Pale Dew (`#EAF4F4`), text `#2D3748`. Active: Sage Green (`#6B9080`), text `#FFFFFF`.
- **Status Tags**: Muted mint (`#CCE3DE`) for active attendees; soft sunset (`#F4A261` at 20% opacity) for newcomers; warm earth (`#E76F51` at 15% opacity) for absent or check-in-needed status.

### Form Inputs & Checkboxes
- **Text Inputs**: Large 52px height, 12px corner radius, background `#FFFFFF`, border `1.5px solid #E9E4DC`. Active focus transitions to `#6B9080` border with a 3px soft halo of `rgba(107, 144, 128, 0.20)`. Helper labels are permanent, not floating, ensuring clarity for elder volunteers.
- **Checkboxes & Radios**: 24px x 24px oversized hit boxes. Checked state fills with `#6B9080`, displaying an organic soft white tick mark.
- **Search & Quick Member Lookup**: Prominent magnifying pill input, embedded with a gentle leaf icon and Warm Cream interior.

### Lists & Activity Logs
- **Attendance Rows**: Generous 64px row height with clear tap targets, separated by hairline borders (`#E9E4DC`). Alternating or hovered states invoke faint airy washes (`#EAF4F4` at 50% opacity).
- **Volunteer Quick Toggles**: Pill toggle buttons right-aligned for one-tap attendance marking ("Present", "Excused", "Assisting").

### Holistic Wellness Additions
- **Lotus Progress Bar**: Segmented horizontal track colored with soft steps (`#CCE3DE` filling to `#6B9080` and capped with `#F4A261`) representing group practice goals or volunteer milestone shifts.
- **Gentle Notice Banners**: Pill-cornered notification banners with warm terra-cotta tint (`#FAF0EB`) and `#E76F51` border for kindly sharing schedule changes or weather cancellations.